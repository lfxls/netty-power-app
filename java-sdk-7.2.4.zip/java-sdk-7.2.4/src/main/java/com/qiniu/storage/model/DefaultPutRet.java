package com.qiniu.storage.model;

public final class DefaultPutRet {
    public String hash;
    public String key;
}
