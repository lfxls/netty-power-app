package com.qiniu.storage.model;

/**
 * Created by bailong on 15/2/23.
 */
public final class ResumeBlockInfo {
    public String ctx;
    public long crc32;
}
