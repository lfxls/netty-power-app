package com.qiniu.http;

/**
 * Created by bailong on 16/9/23.
 */
public final class Error {
    public String error;
}
